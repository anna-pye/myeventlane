#ddev-generated
*.cnf files in .ddev/mysql are added to the project's MySQL/MariaDB configuration.

More information is at
https://ddev.readthedocs.io/en/stable/users/extend/customization-extendibility/#custom-mysqlmariadb-configuration-mycnf

For example, if you rename the provided character-set.cnf.example
to character-set.cnf, its configuration will be added to your MySQL/MariaDB configuration.


