#ddev-generated
Scripts in this directory will be executed inside the db
container. A number of environment variables are supplied to the scripts.

See https://ddev.readthedocs.io/en/stable/users/extend/custom-commands/#environment-variables-provided for a list of environment variables.
