<?php

namespace Drupal\myeventlane_rsvp\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\Entity\Node;
use Drupal\paragraphs\Entity\Paragraph;

/**
 * RSVP submission form (dynamic, supports event-level extra questions).
 */
class RSVPSubmissionForm extends FormBase {

  public function getFormId() {
    return 'myeventlane_rsvp_submission_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state, $event_id = NULL) {
    if (empty($event_id) || !is_numeric($event_id)) {
      \Drupal::messenger()->addError($this->t('This RSVP form is missing its Event context. Please return to the event page and try again.'));
      return [];
    }

    $form['event_id'] = [
      '#type' => 'hidden',
      '#value' => $event_id,
    ];
    $form['first_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Your First Name'),
      '#required' => TRUE,
      '#attributes' => ['class' => ['rsvp-field', 'rsvp-field--name']],
    ];
    $form['last_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Your Last Name'),
      '#required' => TRUE,
      '#attributes' => ['class' => ['rsvp-field', 'rsvp-field--name']],
    ];
    $form['email'] = [
      '#type' => 'email',
      '#title' => $this->t('Your Email'),
      '#required' => TRUE,
      '#attributes' => ['class' => ['rsvp-field', 'rsvp-field--email']],
    ];
    $form['comments'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Comments or Questions'),
      '#attributes' => ['class' => ['rsvp-field', 'rsvp-field--comments']],
      '#description' => $this->t('Optional: Is there anything you want the organiser to know, or any accessibility needs?'),
      '#placeholder' => $this->t('e.g., I have dietary needs, or will arrive late...'),
      '#required' => FALSE,
    ];

    // Dynamically add extra fields from Paragraphs on the event.
      if ($event_id) {
        $event = Node::load(is_array($event_id) ? reset($event_id) : $event_id);
      if (empty($event_id) || !is_numeric($event_id)) {
        \Drupal::messenger()->addError($this->t('This RSVP form is missing its Event context. Please return to the event page and try again.'));
        return $form; // Or return an empty form/redirect as appropriate
       }
      if ($event && $event->hasField('field_attendee_questions')) {
        foreach ($event->get('field_attendee_questions') as $delta => $ref) {
          /** @var Paragraph $para */
          $para = $ref->entity;
          if ($para) {
            $field_label = $para->get('field_label')->value;
            $field_type = $para->get('field_type')->value;
            $field_options = $para->get('field_options')->value ?? '';
            $field_name = 'extra_' . $delta;
            switch ($field_type) {
              case 'textfield':
                $form[$field_name] = [
                  '#type' => 'textfield',
                  '#title' => $field_label,
                  '#required' => FALSE,
                ];
                break;
              case 'textarea':
                $form[$field_name] = [
                  '#type' => 'textarea',
                  '#title' => $field_label,
                  '#required' => FALSE,
                ];
                break;
              case 'select':
              case 'radio':
                $options = [];
                foreach (explode("\n", $field_options) as $opt) {
                  $opt = trim($opt);
                  if ($opt !== '') {
                    $options[$opt] = $opt;
                  }
                }
                $form[$field_name] = [
                  '#type' => $field_type === 'select' ? 'select' : 'radios',
                  '#title' => $field_label,
                  '#options' => $options,
                  '#required' => FALSE,
                ];
                break;
              case 'checkboxes':
                $options = [];
                foreach (explode("\n", $field_options) as $opt) {
                  $opt = trim($opt);
                  if ($opt !== '') {
                    $options[$opt] = $opt;
                  }
                }
                $form[$field_name] = [
                  '#type' => 'checkboxes',
                  '#title' => $field_label,
                  '#options' => $options,
                  '#required' => FALSE,
                ];
                break;
              }
            }
          }
        }
      }

      $form['submit'] = [
        '#type' => 'submit',
        '#value' => $this->t('RSVP Now'),
        '#attributes' => ['class' => ['button', 'button--primary', 'rsvp-submit-btn']],
      ];

      return $form;
    }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();
    $event_id = $values['event_id'];
    if (is_array($event_id)) {
      $event_id = reset($event_id);
    }
    $extra_answers = [];
    foreach ($form as $key => $element) {
      if (strpos($key, 'extra_') === 0) {
        $extra_answers[$key] = $values[$key];
      }
    }
    \Drupal::database()->insert('myeventlane_rsvp')
      ->fields([
        'event_nid'     => $event_id,
        'first_name'    => $values['first_name'],
        'last_name'     => $values['last_name'],
        'email'         => $values['email'],
        'comments'      => $values['comments'],
        'created'       => \Drupal::time()->getRequestTime(),
        'extra_answers' => json_encode($extra_answers),
      ])
      ->execute();

    \Drupal::messenger()->addStatus($this->t('Thanks for your RSVP!'));
   }
  }

